from sqlalchemy import create_engine, text
from sqlalchemy.exc import ProgrammingError
import os
from dotenv import load_dotenv

def run():
    print("📦 Running migration: 014_add_grid_number_column_to_components_layout")

    load_dotenv()
    mysql_url = os.getenv("MYSQL_URL")

    engine = create_engine(mysql_url)
    conn = engine.connect()
    table_name = "component_layouts"  # Change this if your table name differs

    # Add 'grid_number' column with default 0
    try:
        conn.execute(
            text(f"ALTER TABLE {table_name} ADD COLUMN grid_number INT NOT NULL DEFAULT 0;")
        )
        print("✅ Added 'grid_number' column with default 0")
    except ProgrammingError as e:
        print(f"⚠ Skipping 'grid_number' addition: {e}")

    # Ensure all existing rows have grid_number = 0
    try:
        conn.execute(
            text(f"UPDATE {table_name} SET grid_number = 0 WHERE grid_number IS NULL;")
        )
        print("✅ Updated existing rows to have grid_number = 0")
    except ProgrammingError as e:
        print(f"⚠ Skipping existing data update: {e}")

    conn.close()
    print("✅ Completed migration: 014_add_grid_number_column_to_component_layouts")

if __name__ == "__main__":
    run()
