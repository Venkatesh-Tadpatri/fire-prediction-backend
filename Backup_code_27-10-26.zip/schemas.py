from pydantic import BaseModel, validator
from pydantic import EmailStr 
from datetime import datetime
from typing import Optional
from typing import List



class SensorDataCreate(BaseModel):
    temperature: float
    humidity: float
    smoke_level: float
    voltage: float
    air_velocity: float
    pressure: float
    timestamp: datetime


class SensorData(BaseModel):
    id: int
    temperature: float
    humidity: float
    smoke_level: float
    voltage: float
    air_velocity: float
    pressure: float
    timestamp: datetime
    class Config:
        orm_mode = True
        from_attributes: True


class UserCreate(BaseModel):
    name: str
    last_name: str
    email: EmailStr
    contact_number: str
    password: str
    confirm_password: str

    # Optional: extra validation
    @validator("contact_number")
    def contact_must_be_10_digits(cls, v):
        if not v.isdigit() or len(v) != 10:
            raise ValueError("Contact number must be 10 digits")
        return v

    @validator("confirm_password")
    def passwords_match(cls, v, values):
        if "password" in values and v != values["password"]:
            raise ValueError("Passwords do not match")
        return v


class MessageResponse(BaseModel):
    message: str    

class UserResponse(BaseModel):
    id: int
    name: str
    last_name: str
    email: EmailStr
    contact_number: str


class EmailRequest(BaseModel):
    email: EmailStr


class UserProfileResponse(BaseModel):
    name: str
    last_name: str
    contact_number: str
    email: EmailStr


class UpdateUserRequest(BaseModel):
    email: EmailStr
    name: Optional[str] = None
    last_name: Optional[str] = None
    contact_number: Optional[str] = None


class PanelRiskDataCreate(BaseModel):
    panel_name: str
    I_phaseA: float
    rated_current: float
    R_contact_norm: float
    T_contact_norm: float
    HF_I_env_norm: float
    US_sig_norm: float
    thermal_gradient_norm: float
    IR_norm: float
    I_leak_norm: float
    transient_peak_norm: float
    pulse_rate_norm: float
    HF_energy_norm: float
    T_bus_norm: float
    PD_trend_norm: float
    neutral_imbalance: float

class RiskResponse(BaseModel):
    risk_score: float
    risk_level: str
    created_at: str  # or datetime if you prefer


class UPSDataSchema(BaseModel):
    ups_id: str
    ups_name: str
    I: float
    V: float
    PF: float
    TUPS: float
    IL: float
    THD: float

class RiskResponse(BaseModel):
    risk_score: float
    risk_level: str
    created_at: datetime  

class ACRiskResponse(BaseModel):
    risk_score: float
    risk_level: str
    created_at: str   

# # ✅ Request model for a single component layout
# class ComponentLayoutBase(BaseModel):
#     user_name: str
#     floor_name: str
#     component_name: str
#     instance_id: str
#     position_x: float
#     position_y: float     


class ComponentBase(BaseModel):
    floor_name: str
    component_name: str
    instance_id: str
    position_x: float
    position_y: float

class ComponentCreateRequest(BaseModel):
    user_name: str
    components: List[ComponentBase]



    class Config:
        from_attributes = True  # replaces orm_mode=True in Pydantic v2  


        
              
